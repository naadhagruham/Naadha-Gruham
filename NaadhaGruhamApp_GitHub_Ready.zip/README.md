# Naadha Gruham App v2

Standalone Android app source for Naadha Gruham.

## Included in v2
- Student management
- Course and per-student per-class rate
- Attendance / class count
- Automatic fee due = classes x per-class rate
- Payment recording and balance
- Local persistence on the phone
- Fee statement/receipt generation
- Receipt sharing foundation
- Dashboard totals

## Fee model
ONLY per-class fees are implemented. There is no monthly, quarterly, yearly, course-fee or crash-course fee engine.

## Build
Open this project in Android Studio with an Android SDK and build an APK. This chat environment does not currently include the Android SDK/Gradle toolchain, so an APK cannot be compiled here.


## Build APK on GitHub (phone-friendly)

This repository includes `.github/workflows/android.yml`.
After uploading the project to GitHub, open **Actions** → **Build Naadha Gruham APK** → **Run workflow**.
When the workflow finishes, open the run and download the **NaadhaGruham-debug-apk** artifact.
